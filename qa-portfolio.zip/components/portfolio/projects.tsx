import { ExternalLink, Github, Folder, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

const projects = [
  {
    title: "E2E Testing Framework",
    description: "A comprehensive end-to-end testing framework built with Playwright and TypeScript. Features parallel execution, visual regression testing, and detailed HTML reports.",
    tech: ["Playwright", "TypeScript", "GitHub Actions", "Allure"],
    github: "#",
    demo: "#",
    featured: true,
  },
  {
    title: "API Test Suite",
    description: "Automated API testing solution with comprehensive coverage for RESTful services. Includes data-driven testing, schema validation, and performance benchmarks.",
    tech: ["Postman", "Newman", "JavaScript", "Jenkins"],
    github: "#",
    demo: "#",
  },
  {
    title: "Mobile Testing Automation",
    description: "Cross-platform mobile test automation framework supporting both iOS and Android applications with Appium and BrowserStack integration.",
    tech: ["Appium", "Python", "BrowserStack", "pytest"],
    github: "#",
    demo: "#",
  },
  {
    title: "Performance Testing Dashboard",
    description: "Real-time performance monitoring dashboard that visualizes K6 test results with custom metrics, trends, and alerting capabilities.",
    tech: ["K6", "Grafana", "InfluxDB", "Docker"],
    github: "#",
    demo: "#",
  },
]

export function Projects() {
  return (
    <section id="projects" className="py-24 px-6 relative">
      <div className="container mx-auto max-w-6xl relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 section-title">
            Featured Projects
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto rounded-full mb-4 animate-pulse-glow" />
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A selection of testing frameworks and automation projects I&apos;ve built 
            to solve real-world quality assurance challenges.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((project, index) => (
            <div 
              key={index}
              className={`glass-warm rounded-xl p-6 hover:border-primary/50 transition-all duration-300 group relative overflow-hidden card-hover ${
                project.featured ? 'md:col-span-2' : ''
              }`}
            >
              {project.featured && (
                <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 rounded-full bg-primary/20 text-primary text-xs badge-glow">
                  <Sparkles className="w-3 h-3" />
                  Featured
                </div>
              )}
              
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-colors icon-glow">
                  <Folder className="w-6 h-6 text-primary" />
                </div>
                <div className="flex items-center gap-3">
                  <a 
                    href={project.github}
                    className="w-8 h-8 rounded-lg bg-secondary/50 flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/20 transition-all"
                    aria-label="View source code"
                  >
                    <Github size={16} />
                  </a>
                  <a 
                    href={project.demo}
                    className="w-8 h-8 rounded-lg bg-secondary/50 flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/20 transition-all"
                    aria-label="View live demo"
                  >
                    <ExternalLink size={16} />
                  </a>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                {project.title}
              </h3>
              
              <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                {project.description}
              </p>

              <div className="flex flex-wrap gap-2">
                {project.tech.map((tech, techIndex) => (
                  <span 
                    key={techIndex}
                    className="px-3 py-1 text-xs font-mono bg-secondary/50 text-primary rounded-full hover:bg-primary/20 transition-colors badge-glow"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" asChild className="border-primary/50 hover:bg-primary/10 animate-border-glow">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer">
              <Github className="mr-2 h-4 w-4" />
              View More on GitHub
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}
